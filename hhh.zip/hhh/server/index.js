import express from 'express'
import cors from 'cors'

const app = express()
app.use(cors())
app.use(express.json())

let equipment = [
  { id: 1, name: 'Станок', status: 'Работает' },
  { id: 2, name: 'Насос', status: 'Ремонт' },
  { id: 3, name: 'Двигатель', status: 'Простой' }
]
let requests = [
  { id: 1, equipmentId: 2, equipmentName: 'Насос', type: 'Ремонт', description: 'Проверить насос', priority: 'Высокий', status: 'Новая' }
]
let nextEquipmentId = 4
let nextRequestId = 2

app.post('/api/login', (req, res) => {
  const { email, password } = req.body
  if (email === 'admin@toir.ru' && password === '12345') {
    return res.json({ token: 'demo-token', email })
  }
  res.status(401).json({ error: 'Неверный email или пароль (401)' })
})

app.get('/api/equipment', (req, res) => res.json(equipment))
app.post('/api/equipment', (req, res) => {
  if (!req.body.name) return res.status(400).json({ error: 'Введите название оборудования' })
  const item = { id: nextEquipmentId++, name: req.body.name, status: req.body.status || 'Работает' }
  equipment.push(item)
  res.status(201).json(item)
})
app.put('/api/equipment/:id', (req, res) => {
  const item = equipment.find(e => e.id === Number(req.params.id))
  if (!item) return res.status(404).json({ error: 'Оборудование не найдено' })
  Object.assign(item, { name: req.body.name, status: req.body.status })
  res.json(item)
})

app.get('/api/requests', (req, res) => res.json(requests))
app.post('/api/requests', (req, res) => {
  if (!req.body.equipmentId || !req.body.type || !req.body.description) {
    return res.status(400).json({ error: 'Заполните все поля заявки' })
  }
  const item = {
    id: nextRequestId++,
    equipmentId: Number(req.body.equipmentId),
    equipmentName: req.body.equipmentName || equipment.find(e => e.id === Number(req.body.equipmentId))?.name || 'Не выбрано',
    type: req.body.type,
    description: req.body.description,
    priority: req.body.priority || 'Средний',
    status: 'Новая'
  }
  requests.push(item)
  res.status(201).json(item)
})

app.listen(3000, () => console.log('REST API запущен: http://localhost:3000'))