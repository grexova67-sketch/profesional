<template>
  <section>
    <div class="heading"><h2>Заявки</h2><button @click="open()">+ Новая заявка</button></div>
    <div class="filters">
      <select v-model="status"><option value="">Все статусы</option><option>Новая</option><option>В работе</option><option>Закрыта</option></select>
      <select v-model="priority"><option value="">Все приоритеты</option><option>Высокий</option><option>Средний</option><option>Низкий</option></select>
    </div>
    <div class="panel table-wrap">
      <table>
        <thead><tr><th>ID</th><th>Оборудование</th><th>Тип / описание</th><th>Приоритет</th><th>Статус</th></tr></thead>
        <tbody>
          <tr v-for="item in filtered" :key="item.id">
            <td>{{ item.id }}</td><td>{{ item.equipmentName }}</td><td>{{ item.description }}</td><td>{{ item.priority }}</td><td>{{ item.status }}</td>
          </tr>
          <tr v-if="!filtered.length"><td colspan="5">Заявок нет</td></tr>
        </tbody>
      </table>
    </div>

    <div v-if="modal" class="overlay">
      <form class="modal panel" @submit.prevent="save">
        <h3>Создать заявку</h3>
        <label>Оборудование<select v-model="form.equipmentId" required><option disabled value="">Выберите оборудование</option><option v-for="e in equipment" :key="e.id" :value="e.id">{{ e.name }}</option></select></label>
        <label>Тип работ<input v-model="form.type" required placeholder="Например, ремонт"></label>
        <label>Приоритет<select v-model="form.priority"><option>Высокий</option><option>Средний</option><option>Низкий</option></select></label>
        <label>Описание<textarea v-model="form.description" required></textarea></label>
        <div class="actions"><button>Создать</button><button type="button" class="secondary" @click="modal=false">Отмена</button></div>
      </form>
    </div>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
const props = defineProps({
  items: { type: Array, default: () => [] },
  equipment: { type: Array, default: () => [] }
})
const emit = defineEmits(['save'])
const status = ref('')
const priority = ref('')
const modal = ref(false)
const form = ref({ equipmentId: '', type: '', priority: 'Средний', description: '' })
const filtered = computed(() => props.items
  .filter(r => !status.value || r.status === status.value)
  .filter(r => !priority.value || r.priority === priority.value))
function open() {
  form.value = { equipmentId: '', type: '', priority: 'Средний', description: '' }
  modal.value = true
}
function save() {
  const equipment = props.equipment.find(e => e.id === Number(form.value.equipmentId))
  emit('save', { ...form.value, equipmentId: Number(form.value.equipmentId), equipmentName: equipment?.name || 'Не выбрано' })
  modal.value = false
}
</script>