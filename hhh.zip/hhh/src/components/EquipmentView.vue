<template>
  <section>
    <div class="heading"><h2>Оборудование</h2><button @click="open()">+ Добавить</button></div>
    <div class="filters">
      <input v-model="search" placeholder="Поиск по названию">
      <select v-model="status">
        <option value="">Все статусы</option>
        <option>Работает</option><option>Ремонт</option><option>Простой</option>
      </select>
      <select v-model="sort">
        <option value="name">Сортировать по названию</option>
        <option value="status">Сортировать по статусу</option>
      </select>
    </div>
    <div class="panel table-wrap">
      <table>
        <thead><tr><th>ID</th><th>Название</th><th>Статус</th><th>Действие</th></tr></thead>
        <tbody>
          <tr v-for="item in filtered" :key="item.id">
            <td>{{ item.id }}</td><td>{{ item.name }}</td><td>{{ item.status }}</td>
            <td><button class="small" @click="open(item)">Изменить</button></td>
          </tr>
          <tr v-if="!filtered.length"><td colspan="4">Ничего не найдено</td></tr>
        </tbody>
      </table>
    </div>

    <div v-if="modal" class="overlay">
      <form class="modal panel" @submit.prevent="save">
        <h3>{{ form.id ? 'Редактировать оборудование' : 'Новое оборудование' }}</h3>
        <label>Название<input v-model="form.name" required></label>
        <label>Статус<select v-model="form.status"><option>Работает</option><option>Ремонт</option><option>Простой</option></select></label>
        <div class="actions"><button>Сохранить</button><button type="button" class="secondary" @click="modal=false">Отмена</button></div>
      </form>
    </div>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
const props = defineProps({ items: { type: Array, default: () => [] } })
const emit = defineEmits(['save'])
const search = ref('')
const status = ref('')
const sort = ref('name')
const modal = ref(false)
const form = ref({ name: '', status: 'Работает' })

const filtered = computed(() => props.items
  .filter(e => e.name.toLowerCase().includes(search.value.toLowerCase()))
  .filter(e => !status.value || e.status === status.value)
  .slice().sort((a, b) => String(a[sort.value]).localeCompare(String(b[sort.value]), 'ru')))

function open(item) {
  form.value = item ? { ...item } : { name: '', status: 'Работает' }
  modal.value = true
}
function save() {
  emit('save', { ...form.value })
  modal.value = false
}
</script>