<template>
  <div class ="app">
    <header><h1>ТОиР</h1><span>Панель управления</span></header>

    <main v-if="!user" class="login panel">
      <h2>Вход в систему</h2>
      <form @submit.prevent="login">
        <input v-model="email" type="email" placeholder="Email" required>
        <input v-model="password" type="password" placeholder="Пароль" required>
        <button :disabled="loading">{{ loading ? 'Входим...' : 'Войти' }}</button>
      </form>
      <small>Демо-вход: admin@mail.ru / 12345</small>
    </main>

    <main v-else> 
      <nav>
        <button :class="{active: page==='home'}" @click="page='home'">Главная</button>
        <button :class="{active: page==='equipment'}" @click="page='equipment'">Оборудование</button>
        <button :class="{active: page==='requests'}" @click="page='requests'">Заявки</button>
        <button class="exit" @click="user=false">Выйти</button>
      </nav>

      <p v-if="loading" class="info">Загрузка данных...</p>
      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }} <button @click="error=''">Закрыть</button></p>

      <section v-if="page==='home'">
        <h2>Главный дашборд</h2>
        <div class="cards">
          <div class="card"><span>Всего оборудования</span><strong>{{ equipment.length }}</strong></div>
          <div class="card"><span>Активные заявки</span><strong>{{ activeRequests }}</strong></div>
          <div class="card"><span>Простой за месяц</span><strong>{{ downtime }} ч</strong></div>
        </div>
        <div class="panel">
          <h3>Оборудование по статусам</h3>
          <div v-for="(count, status) in statusCounts" :key="status" class="bar-row">
            <span>{{ status }}</span><div class="bar"><i :style="{width: (count / Math.max(equipment.length, 1) * 100) + '%'}"></i></div><b>{{ count }}</b>
          </div>
        </div>
      </section>

      <EquipmentView v-if="page==='equipment'" :items="equipment" @save="saveEquipment" />
      <RequestsView v-if="page==='requests'" :items="requests" :equipment="equipment" @save="saveRequest" />
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { api } from './api'
import EquipmentView from './components/EquipmentView.vue'
import RequestsView from './components/RequestsView.vue'

const user = ref(false)
const email = ref('admin@toir.ru')
const password = ref('12345')
const page = ref('home')
const loading = ref(false)
const error = ref('')
const message = ref('')
const equipment = ref([])
const requests = ref([])
const downtime = ref(12)

const activeRequests = computed(() => requests.value.filter(r => r.status !== 'Закрыта').length)
const statusCounts = computed(() => {
  const result = {}
  equipment.value.forEach(item => result[item.status] = (result[item.status] || 0) + 1)
  return result
})

async function run(action) {
  loading.value = true
  error.value = ''
  message.value = ''
  try { return await action() }
  catch (e) { error.value = e.message }
  finally { loading.value = false }
}

async function loadData() {
  await run(async () => {
    equipment.value = await api.equipment()
    requests.value = await api.requests()
  })
}

async function login() {
  await run(async () => {
    await api.login({ email: email.value, password: password.value })
    user.value = true
    await loadData()
  })
}

async function saveEquipment(item) {
  await run(async () => {
    await api.saveEquipment(item)
    message.value = 'Оборудование сохранено'
    await loadData()
  })
}

async function saveRequest(item) {
  await run(async () => {
    await api.saveRequest(item)
    message.value = 'Заявка создана'
    await loadData()
  })
}
</script>